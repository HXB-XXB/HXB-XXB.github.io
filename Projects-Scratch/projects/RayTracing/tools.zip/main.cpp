// main.cpp
// 编译时需要先下载 stb_image.h 到同目录
// 下载地址: https://raw.githubusercontent.com/nothings/stb/master/stb_image.h

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <string>

int main(int argc, char* argv[])
{
	const char* inputFile = (argc > 1) ? argv[1] : "background.png";
	const char* outputFile = (argc > 2) ? argv[2] : "background.txt";
	
	int width = 0, height = 0, channels = 0;
	// 强制请求 4 通道 (RGBA)，方便统一处理
	unsigned char* data = stbi_load(inputFile, &width, &height, &channels, 4);
	if (!data)
	{
		std::cerr << "Failed to load image: " << inputFile
		<< "\nReason: " << stbi_failure_reason() << std::endl;
		return 1;
	}
	
	std::ofstream out(outputFile, std::ios::binary);
	if (!out)
	{
		std::cerr << "Failed to open output file: " << outputFile << std::endl;
		stbi_image_free(data);
		return 1;
	}
	
	// 第一行: 长 (width)
	// 第二行: 宽 (height)
	out << width << '\n';
	out << height << '\n';
	
	// 逐个像素输出 RGB 十六进制，小写，不带 0x，忽略 alpha
	const char* hexDigits = "0123456789abcdef";
	char buf[7];
	buf[6] = '\0';
	
	const size_t pixelCount = static_cast<size_t>(width) * static_cast<size_t>(height);
	for (size_t i = 0; i < pixelCount; ++i)
	{
		const unsigned char* p = data + i * 4;
		unsigned char r = p[0];
		unsigned char g = p[1];
		unsigned char b = p[2];
		
		buf[0] = hexDigits[(r >> 4) & 0xF];
		buf[1] = hexDigits[r & 0xF];
		buf[2] = hexDigits[(g >> 4) & 0xF];
		buf[3] = hexDigits[g & 0xF];
		buf[4] = hexDigits[(b >> 4) & 0xF];
		buf[5] = hexDigits[b & 0xF];
		
		out.write(buf, 6);
		out.put('\n');
	}
	
	stbi_image_free(data);
	out.close();
	
	std::cout << "Done. " << width << "x" << height
	<< " pixels written to " << outputFile << std::endl;
	return 0;
}
