#include <windows.h>
#include <iostream>
#include <vector>
#include <iomanip>
#include <string>
#include <cstdio>

using namespace std;

const int RES=2;

vector<BYTE> GetCharBitmap(HDC hdc, wchar_t ch, int& width, int& height, int& yOffset) {
    HFONT hFont = (HFONT)GetCurrentObject(hdc, OBJ_FONT);
    
    GLYPHMETRICS gm;
    MAT2 mat2 = { {0,1}, {0,0}, {0,0}, {0,1} };
    
    DWORD size = GetGlyphOutlineW(hdc, ch, GGO_GRAY8_BITMAP, &gm, 0, nullptr, &mat2);
    if (size == GDI_ERROR || size == 0) return {};
    
    vector<BYTE> buffer(size);
    if (GetGlyphOutlineW(hdc, ch, GGO_GRAY8_BITMAP, &gm, size, buffer.data(), &mat2) == GDI_ERROR) {
        return {};
    }
    
    width = gm.gmBlackBoxX;
    height = gm.gmBlackBoxY;
    yOffset = gm.gmptGlyphOrigin.y;
    
    if (width == 0 || height == 0) return {};
    
    vector<BYTE> bitmap(width * height);
    int bytesPerRow = (width + 3) & ~3;
    for (int y = 0; y < height; y++) {
        memcpy(&bitmap[y * width], &buffer[y * bytesPerRow], width);
    }
    
    return bitmap;
}

string getsss(int x) {
    if (x == 0) return "000";
    
    string ans = "";
    while(x) {
        if(x % 16 > 9) ans = char('a' + x % 16 - 10) + ans;
        else ans = char('0' + x % 16) + ans;
        x /= 16;
    }
    while(ans.size() < 3) ans = '0' + ans;
    return ans;
}

void PrintHex(const vector<BYTE>& data, int width, int height, int yOffset, int res) {
//	cout<<"\n";
    cout << getsss(width/res) << getsss(height/res) << getsss(yOffset/res);
	
    string str;
    int cnt = 0;
    bool lastB = 0;
    bool first = true;
    
    for (int y = 0; y < height/res; y++) {
        for (int x = 0; x < width/res; x++) {
            int s = (int)data[(y * width + x)*res];
            bool bk = (s > 4 ? 1 : 0);
            
            if (lastB ^ bk) {
//        		cout<<"["<<cnt<<"]";
                str += getsss(cnt);
                cnt = 1;
                lastB = bk;
            } else {
                cnt++;
            }
            
//            cout<<bk;
        }
//        cout<<"\n";
    }
    
    str += getsss(cnt);
    
    cout << str;
}

void gettt(int l, int r, HDC hdc) {
    SetConsoleOutputCP(CP_UTF8);
    
    for(unsigned int code_point = l; code_point <= r; code_point++) {
        wchar_t wch = static_cast<wchar_t>(code_point);
        int width, height, yOffset;
        
        vector<BYTE> bitmap = GetCharBitmap(hdc, wch, width, height, yOffset);
        
        char utf8_buf[8] = {0};
        WideCharToMultiByte(CP_UTF8, 0, &wch, 1, utf8_buf, 8, NULL, NULL);
        cout << utf8_buf;
        
        
        if (!bitmap.empty()) {
            PrintHex(bitmap, width, height, yOffset, RES);
        }
        cout << endl;
    }
}

int main() {
    HDC hdc = CreateCompatibleDC(nullptr);
    if (!hdc) return 1;
    
    // ��������
    HFONT hFont = CreateFontW(
        48, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
        DEFAULT_CHARSET, OUT_TT_PRECIS, CLIP_DEFAULT_PRECIS,
        PROOF_QUALITY, DEFAULT_PITCH | FF_DONTCARE, L"WYC_YS"
    );
    
    if (!hFont) {
        hFont = CreateFontW(48, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
                           DEFAULT_CHARSET, OUT_TT_PRECIS, CLIP_DEFAULT_PRECIS,
                           PROOF_QUALITY, DEFAULT_PITCH | FF_DONTCARE, L"SimHei");
    }
    
    if (!hFont) {
        DeleteDC(hdc);
        cerr << "Failed to create font!" << endl;
        return 1;
    }
    
    SelectObject(hdc, hFont);
    
    freopen("font_data.txt", "w", stdout);
    
    
    cout<<"WYC_YS\n";
    cout<<RES<<"\n";
//    gettt(0x0020,0x002F,hdc);//Ӣ�ı�� 
//    gettt(0x0030,0x0039,hdc);//
//    gettt(0x003A,0x0040,hdc);//Ӣ�ı�� 
//    gettt(0x0041,0x005A,hdc);//��дӢ�� 
//    gettt(0x005B,0x0060,hdc);//Ӣ�ı�� 
//    gettt(0x0061,0x007A,hdc);//СдӢ�� 
//    gettt(0x007B,0x007E,hdc);//Ӣ�ı�� 
//    gettt(0x3000,0x303F,hdc);//���ı�� 
//    gettt(0x4E00,0x9FFF,hdc);//���� 
//    gettt(0xFF00,0xFF20,hdc);//ȫ�Ǳ�� 
//    gettt(0xFF1A,0xFF20,hdc);//ȫ�Ǳ�� 

    gettt(0x0000,0xFFFF,hdc);//���� 
    
    DeleteObject(hFont);
    DeleteDC(hdc);
    
    return 0;
}
